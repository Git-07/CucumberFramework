package StepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Travel {
	
	WebDriver driver = null;	
	WebDriverWait wait;
	@Before("@travel")
	public void browserSetup() {
	    System.setProperty("webdriver.chrome.driver","./Drivers/chromedriver.exe");	    
	    driver = new ChromeDriver();
	    driver.manage().window().maximize();
	    wait  = new WebDriverWait (driver,30);
		
	}
	@After("@travel")
	public void tearDown() {
			
		driver.quit();
		
	}
	public void selectValue(WebElement element, String value){

		Select select = new Select(element);		
		select.selectByValue(value);
		}
	public void highlightElement(WebElement element) {
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].setAttribute('style','border: solid 2px green')", element);
	}
	
	
	@Given("User navigate to the {string}")
	public void user_navigate_to_the(String url) {
		driver.get(url);		
	    
	}

	@And("Click on the register link")
	public void click_on_the_register_link() {
	   	    
	WebElement registerLink = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[contains(text(),'REGISTER')]")));
	highlightElement(registerLink);
	registerLink.click();	
	
	}
	@And("User Enter First name {string}")
	public void user_Enter_First_name(String fName) {
		
		WebElement firstName = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='firstName']")));
		highlightElement(firstName);
		firstName.sendKeys(fName);
	}

	@And("User Enter Last name {string}")
	public void user_Enter_Last_name(String lName) {
	    
		WebElement lastName = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='lastName']")));
		highlightElement(lastName);
		lastName.sendKeys(lName);
	    
	}

	@And("User Enter Phone number {string}")
	public void user_Enter_Phone_number(String phone) {

		WebElement phoneNum = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='phone']")));
		highlightElement(phoneNum);
		phoneNum.sendKeys(phone);
	    
	}

	@And("User Enter email {string}")
	public void user_Enter_email(String email) {
	  
		WebElement emailId = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("userName")));
		highlightElement(emailId);
		emailId.sendKeys(email);
	    
	}

	@And("User Enter adress {string}")
	public void user_Enter_adress(String add) {
	    
		WebElement address = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='address1']")));
		highlightElement(address);
		address.sendKeys(add);
	    
	}

	@Given("User Enter city {string}")
	public void user_Enter_city(String city) {
	  
		WebElement cityName = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='city']")));
		highlightElement(cityName);
		cityName.sendKeys(city);
	}

	@Given("User Enter state {string}")
	public void user_Enter_state(String state) {
	   
		WebElement stateName = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='state']")));
		highlightElement(stateName);
		stateName.sendKeys(state);

	}
	
	@And("User Enter postal code {string}")
	public void user_Enter_postal_code(String postal) {
	  
		WebElement postalCode = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='postalCode']")));
		highlightElement(postalCode);
		postalCode.sendKeys(postal);
	    
	}

	@Given("User Enter country {string}")
	public void user_Enter_country(String country) {
	  
		WebElement countryName = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@name='country']")));
		highlightElement(countryName);
		selectValue(countryName,country);
		
	}
	
	@And("User Enter User name {string}")
	public void user_Enter_User_name(String user) {
	    
		WebElement userName = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("email")));
		highlightElement(userName);
		userName.sendKeys(user);		
	    
	}

	@And("User Enter password {string}")
	public void user_Enter_password(String pwd) {
	  
		WebElement password = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='password']")));
		highlightElement(password);
		password.sendKeys(pwd);
		
	}

	@And("User Enter Confirm password {string}")
	public void user_Enter_Confirm_password(String confpwd) {

		WebElement confpass = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='confirmPassword']")));
		highlightElement(confpass);
		confpass.sendKeys(confpwd);
	    
	}

	@When("User Click on Submit")
	public void user_Click_on_Submit() {
	    
		WebElement submit = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='submit']")));
		highlightElement(submit);
		submit.click();
	    
	}

	@Then("User Registered Successfully")
	public void user_Registered_Successfully() {
		
		WebElement submit = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//font[contains(text(),'Thank you for registering')]")));
		highlightElement(submit);
		Assert.assertTrue(submit.isDisplayed());
	}


}
