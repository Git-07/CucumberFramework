package StepDefinitions;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AutomationPracticeSignIn {
	
	WebDriver driver = null;	
	WebDriverWait wait;
	String emailid = "";
	private static final DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	@Before("@automationpractice")
	public void browserSetup() {
	    System.setProperty("webdriver.chrome.driver","./Drivers/chromedriver.exe");	    
	    driver = new ChromeDriver();
	    driver.manage().window().maximize();
	    wait  = new WebDriverWait (driver,30);
	}
	@After("@automationpractice")
	public void tearDown() {
			
		driver.quit();
		
	}
	public void selectValue(WebElement element, String value){

		Select select = new Select(element);
		select.selectByIndex(2);
		//selectByValue(value);
		}

	public void highlightElement(WebElement element) {
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].setAttribute('style','border: solid 2px green')", element);
	}
	public String getCurrentDate() throws Throwable {
		Date currentDate = new Date();
        Calendar c = Calendar.getInstance();
        c.setTime(currentDate);   
        return dateFormat.format(c.getTime());
	}
	
	@Given("User Navigate to {string}")
	public void user_Navigate_to(String url) {
	 
		driver.get(url);	    	   
	}
   
	@And("User Click Sign In Button")
	public void user_click_Sign_In() {
		
		WebElement signIn = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[contains(text(),'Sign in')]")));
		highlightElement(signIn);
		signIn.click();
	}
	@And("User Enter {string}")
	public void user_Enter_Email_Id(String email) throws Throwable{
	   WebElement emailId = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("email_create")));	   
	   highlightElement(emailId);
	   emailId.sendKeys(email);
	   emailid = email;
	}

	@And("User Click on Create an account")
	public void user_Click_on_Create_an_account() throws Throwable {
		String date = getCurrentDate();
		boolean emailExist = false;
		int today = Integer.parseInt(date.split("\\/")[1]);
		WebElement createAccount = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("SubmitCreate")));
		highlightElement(createAccount);
		createAccount.click();
	    try {
	    	Thread.sleep(2000);
	    	WebElement accountExist = driver.findElement(By.xpath("//li[contains(text(),'An account using this email address has already been registered')]"));
	    	highlightElement(accountExist);
	    	emailExist = accountExist.isDisplayed();
			while (emailExist == true) {
				WebElement emailId = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("email_create")));
				highlightElement(emailId);
				emailId.clear();				
				emailId.sendKeys(emailid + today);
				Thread.sleep(1500);
				highlightElement(createAccount);
				createAccount.click();
				emailExist = false;
				Thread.sleep(2000);				
				try {
					accountExist = driver.findElement(By.xpath("//li[contains(text(),'An account using this email address has already been registered')]"));
					highlightElement(accountExist);
					emailExist = accountExist.isDisplayed();					
				}catch(NoSuchElementException e) {}
				today++;
			}
	    }catch(NoSuchElementException e) {}
	}

	@And("User Select the Gender")
	public void user_Select_the_Gender() {
		WebElement gender= wait.until(ExpectedConditions.presenceOfElementLocated(By.id("id_gender1")));
		highlightElement(gender);
		gender.click();
	    
	}

	@And("User Enter First Name {string}")
	public void user_Enter_First_Name(String fName) {
	   
		WebElement firstName = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("customer_firstname")));		
		highlightElement(firstName);
		firstName.sendKeys(fName);
	}

	@And("User Enter Last Name {string}")
	public void user_Enter_Last_Name(String lName) {
		WebElement lastName = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("customer_lastname")));		
		highlightElement(lastName);
		lastName.sendKeys(lName);
	}

	@And("User Enter Password {string}")
	public void user_Enter_Password(String password) {
	   
		WebElement pwd = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("passwd")));		
		highlightElement(pwd);
		pwd.sendKeys(password);
	}

	@And("User Select {string} , {string} and {string} of birth")
	public void user_Select_date_month_and_year_of_birth(String date, String month, String year) {
	   
		WebElement days = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("days")));
		WebElement months = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("months")));
		WebElement years = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("years")));		
		highlightElement(days);
		selectValue(days,date);
		highlightElement(months);
		selectValue(months,month);
		highlightElement(years);
		selectValue(years,year);			    
	}

	@And("User Enter Address {string}")
	public void user_Enter_Address(String addres) {
	   
		WebElement address = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("address1")));
		highlightElement(address);
		address.sendKeys(addres);
	    
	}

	@And("User Enter City {string}")
	public void user_Enter_City(String cityName) {
	   
		WebElement city	= wait.until(ExpectedConditions.presenceOfElementLocated(By.id("city")));		
		highlightElement(city);
		city.sendKeys(cityName);
		
	}

	@And("User Enter Country {string}")
	public void user_Enter_Country(String countryName) {
	   
		WebElement country	= wait.until(ExpectedConditions.presenceOfElementLocated(By.id("id_country")));		
		highlightElement(country);
		country.sendKeys(countryName);
		
	}

	@And("User Enter State {string}")
	public void user_Enter_State(String stateName)  {
	   
		WebElement state = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("id_state")));		
		highlightElement(state);
		state.sendKeys(stateName);
	}

	@And("User Enter Postal Code {string}")
	public void user_Enter_Postal_Code(String postalCode) {
	   
		WebElement postcode	= wait.until(ExpectedConditions.presenceOfElementLocated(By.id("postcode")));
		highlightElement(postcode);
		postcode.sendKeys(postalCode);
	}

	@And("User Enter Mobile Number {string}")
	public void user_Enter_Mobile_Phone(String mobileNum) {
	   
		WebElement phoneMobile	= wait.until(ExpectedConditions.presenceOfElementLocated(By.id("phone_mobile")));		
		highlightElement(phoneMobile);
		phoneMobile.sendKeys(mobileNum);
	}

	@When("User Click on Register Button")
	public void user_Click_on_Register_Button() {
	   
		WebElement createAccount = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("submitAccount")));
		highlightElement(createAccount);
		createAccount.click();
	}
	
	@Then("User should be successfully registered")
	public void user_should_be_successfully_registered() {
		
		WebElement myAccount = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h1[contains(text(),'My account')]")));
		highlightElement(myAccount);
		Assert.assertTrue(myAccount.isDisplayed());
  }
}