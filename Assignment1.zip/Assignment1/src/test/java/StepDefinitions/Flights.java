package StepDefinitions;


import java.util.Iterator;
import java.util.Set;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Flights {

	WebDriver driver = null;	
	WebDriverWait wait;
	@Before("@flight or @login")
	public void browserSetup() {
	    System.setProperty("webdriver.chrome.driver","./Drivers/chromedriver.exe");	    
	    driver = new ChromeDriver();
	    driver.manage().window().maximize();
	    wait  = new WebDriverWait (driver,30);
		
	}
	@After("@flight or @login")
	public void tearDown() {
			
		driver.quit();
		
	}
	public void highlightElement(WebElement element) {
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].setAttribute('style','border: solid 2px green')", element);
	}
	
	@Given("User launches the url {string}")
	public void user_launches_the_url(String url)  throws Throwable {
	    
	    driver.get(url);	    
			   
	}
	@Then("the user navigates successfully to website")
	public void the_user_navigates_successfully_to_website() throws Throwable {		
		WebElement pageTitle = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(("//img[@src='https://b.staticaa.com/images/logos/airasiacom_logo.svg']"))));
		highlightElement(pageTitle);
		boolean imageLogo = pageTitle.isDisplayed();
		Assert.assertTrue(imageLogo);
	}
	@Given("User Click on Flights Icon")
	public void user_Click_on_Flights_Icon() throws Throwable {

		WebElement flightLogo = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//img[@src='https://a.staticaa.com/images/misc/product-tiles/flight_flat.svg']")));
		highlightElement(flightLogo);
		flightLogo.click();		
	}
	@And("User enters Origin as {string}")
	public void user_enters_Origin_as(String originPlace) throws Throwable {
	 
		WebElement origin = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(text(),'From')]//following-sibling::div//input")));
		highlightElement(origin);
		origin.clear();
		origin.sendKeys(originPlace);
		try {
			WebElement promo = driver.findElement(By.id("wzrk-cancel"));
			highlightElement(promo);
			promo.click();
		}catch(NoSuchElementException e) {}
		origin.clear();
		origin.sendKeys(originPlace);
		origin.sendKeys(Keys.ENTER);
	}
	@And("User enters Destination as {string}")
	public void user_enters_Destination_as(String destinationPlace) throws Throwable {
	  
		WebElement destination = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(text(),'To')]//following-sibling::div//input")));			
		highlightElement(destination);
		destination.sendKeys(destinationPlace);
		destination.sendKeys(Keys.ENTER);
		
	}
	@And("User Select depart date as {string}")
	public void user_Select_depart_date_as(String departureDate) throws Throwable {
	   
		WebElement departDate = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(text(),'Depart date')]//following-sibling::div//input")));
		highlightElement(departDate);
		departDate.clear();
		departDate.sendKeys(departureDate);
	}
	@And("User Select Return date as one way")
	public void user_Select_Return_date_as_one_way() throws Throwable {
		
		WebElement oneWay = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(text(),'One way')]//preceding-sibling::div")));
		highlightElement(oneWay);
		oneWay.click();
		WebElement confirm = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(text(),'Confirm')]")));
		highlightElement(confirm);
		confirm.click();
		
	}
	@When("User Click on Search Button")
	public void user_Click_on_Search_Button() throws Throwable {
	   
		WebElement search = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("aa-web-search-button")));
		highlightElement(search);
		String mainWindow = driver.getWindowHandle();
		search.click();		
		Set<String> s1 = driver.getWindowHandles();
		Iterator<String> i1 = s1.iterator();
		Thread.sleep(3000);
		try {
		while(i1.hasNext()) {
			String childWindow = i1.next();
			if (!mainWindow.equalsIgnoreCase(childWindow)) {
				driver.switchTo().window(childWindow);
			}
		}
		}catch(NoSuchWindowException e) {}
	}
	@Then("User navigated successfully to search flight page")
	public void user_navigated_successfully_to_search_flight_page() throws Throwable {
		
		WebElement selectFlight = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'Select flights')]")));
		highlightElement(selectFlight);
		boolean searchFlight  = selectFlight.isDisplayed();
		Assert.assertTrue(searchFlight);		
	}
	@Given("When User click on Login Button")
	public void when_User_click_on_Login_Button() {
		
		WebElement loginbtn = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//p[contains(text(),'Login/Signup')]")));
		highlightElement(loginbtn);
		loginbtn.click();	    
		
	}

	@And("User Enter username as {string}")
	public void user_Enter_username_as(String username) {
	   
		WebElement userName = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("text-input--login")));
		highlightElement(userName);
		userName.sendKeys(username);
	}

	@And("Enter password as {string}")
	public void enter_password(String passwrd) {
	   
		WebElement password = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("password-input--login")));
		highlightElement(password);
		password.sendKeys(passwrd);
	   
	}

	@When("User Click on Sign In Button")
	public void user_Click_on_Sign_In_Button() {
		try {
			WebElement promo = driver.findElement(By.id("wzrk-cancel"));
			highlightElement(promo);
			promo.click();
		}catch(NoSuchElementException e) {}
		WebElement signIn = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("loginbutton")));
		highlightElement(signIn);
		signIn.click();
	}

	
	@Then("Error message should be displayed {string}")
	public void error_message_should_be_displayed(String err) throws Throwable {
	    
		WebElement errorMsg = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(text(),'Your log in attempts has been unsuccessful')]")));
		highlightElement(errorMsg);
		String error = errorMsg.getText();
		Thread.sleep(2000);		
		boolean ermsg = error.contains(err);				
		Assert.assertTrue(ermsg);
		String color = errorMsg.getCssValue("color");
		Assert.assertEquals("rgba(225, 0, 0, 1)", color);
	}

}
